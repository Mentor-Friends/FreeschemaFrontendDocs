## Widget

A widget is a Building block for our application. Widget is any small functionality that you can think of. In our framework every functionality should be converted to a widget. We are creating this mechanism because we want reusable functionality throught the system and organize our code.


To create a widget you must extend StatefulWidget class. This class has many functionalities relating to the lifecycle of the project. You will find examples of how to create a widget in the Phonebook example below. This phonebook example will help you guide through the process.

