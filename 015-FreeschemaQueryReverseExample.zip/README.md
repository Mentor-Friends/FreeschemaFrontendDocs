Freeschema is a semantic database system that lets us create 
