## Installation

Installation of Freeschema Frontend.



Freeschema is a multi layered system but can be developed with a single package called Freeschema Frontend. This is available in github as https://github.com/Mentor-Friends/Freeschema-Frontend.

The Freeschema has different layers like permanent store, data layer, distribution layer then frontend layer.

This Frontend layer is designed so that we can create an Single page application using our knowledge of javascript. With just javascript and the knowledge of freeschema we can create a complex website. That is the strength of freeschema.



To start using freeschema

```
git clone https://github.com/Mentor-Friends/Freeschema-Frontend 

// then afterwards install all the packages using npm install
npm install 

// now you can run freeschema
npm run dev
```